import { Counter } from './Counter'

export const App = () => {
  return (
    <>
      <h1>React khdjfhkd kkjnk jjkjk ndfdfefdfdssd dfd</h1>
    </>
  )
}
